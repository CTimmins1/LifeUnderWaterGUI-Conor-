/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lifeunderwaterapp;

/**
 *
 * @author Conor T
 */
public class FishInfo extends WildlifeGUI {
    private String sharkInfo;
    private String fishInfo;
    private String shellInfo;
    
    public FishInfo(String sharkInfo, String fishInfo, String shellInfo){
        this.sharkInfo = sharkInfo;
        this.fishInfo = fishInfo;
        this.shellInfo = shellInfo;        
    }
    
    public String getSharkInfo() {
        return sharkInfo;
    }

    public String getFishInfo() {
        return fishInfo;
    }

    public String getShellInfo() {
        return shellInfo;
    }
    
    
}
